/* JANGAN HAPUS WM  !!
SC BY NEROX MD 
RECODE BY HAIDAR
JANGAN LUPA JOIN CH NEW GW : https://whatsapp.com/channel/0029VamzFetC6ZvcD1qde90Z
JANGAN LUPA JOIN GC GW JUGA : https://chat.whatsapp.com/JzcVI6cExQRLlPOFhI2d6u
NOMER NEW GW JANGAN LUPA SV : 6281326447234
*/


const fs = require('fs')
const chalk = require('chalk')
const moment = require('moment-timezone')

//apikey paydisini
global.paydisini = {
api: ""
}

//apikeymu
global.api = {
  xterm: {
    url: "https://ai.xterm.codes",
    key: "Bell409"
  }
};

//Ambil apikey di maupedia.com
global.maupedia = {
  key: "4UXr8IDgyCTaUsKKqLXX5LMeBGJiMyndLLeXeyr7WpQJus8jZ22bBIXRtDZJGt3S",
  signature: "3e8cc5f7adea460d4d89110a5d5a4b02822fad81",
  secret: "Mewing",
};

global.channel = 'https://whatsapp.com/'
global.ig = '' // ISI IG LU KALO ADA
global.thumb = fs.readFileSync("./nerokskibidi.jpg")
global.email = '' // ISI EMAIL LU KALO MAU
global.region = 'Asia/Jepang'
global.wm = 'Laut'
global.wm2 = '_*Powered By Laut*_'
global.chid = '120363329425162176@newsletter' // ID CH LU
global.region = "Asia/Jepang"

global.owner = ['6281326447234'] //KALO OWNER NYA MAU 2 ['6281326447234','NOMER OWNER2']
global.ownername = 'Haidarkun' //NAMA OWNER
global.botnumber = '6281326447234' //NOMOR BOT LU
global.keyopenai = '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'
global.ibeng = 'Yl4h5x9wiA'
global.sherly= '66a4afa9509d747f4ac3' 
global.defaultpp = '' //default pp wa

global.botname = 'Laut'
global.packname = 'Laut'
global.author = `Laut`
global.prefix = ['.']
global.prefa = ['.']
global.sessionName = 'Session - Laut'
global.anticall = true

//digitalocean
global.apido = ''

//setting panel #1
global.domain = '-'
global.apikey = '-'
global.capikey = '-'
global.eggsnya = '15' 
global.location = '1'

//setting panel private
global.domain2 = '-'
global.apikey2 = '-'
global.capikey2 = '-'
global.eggsnya = '15' 
global.location = '1'
global.docker2 = "ghcr.io/cekilpedia/vip:sanzubycekil" //jangan di ubah
//===========================//
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.eggsnya = '15' // id eggs yang dipakai
global.location3 = '1' // id location
//===========================//
global.domainotp = "https://claudeotp.com/api"
global.apikeyotp = "a395f97fe99f4fad0e790d10af518b9a"
global.eggsnya = '15' // id eggs yang dipakai
global.mess = {
    success: 'Suscces Sayangku..',
    admin: '⚠️ *Fitur Khusus Admin Group!*',
    botAdmin: '⚠️ *Fitur Ini Hanya Bisa Digunakan Ketika Bot Menjadi Admin Group!*',
    owner: '⚠️ *Fiturnya Buat Ownerku',
    prem: '⚠️ *Fiturnya, Buat Member Premium Beb..',
    group: '⚠️ *Fitur Digunakan Dalam Group Beb..*',
    wait: '⌛ *Dalam Proses Ya Sayang..*',
    error: '⚠️ *Ada Yang Error Nih, Hubungi Nerox Ya..',
    
    // Fitur Store & Report
    owner2: '6281326447234',
    qris: 'https://pomf2.lain.la/f/zsjrt0n1.jpg',
    format: '🎁 *Pembayaran*\n📣 *All Payment Bisa Scan Qr Diatas(ERROR)*\n\n📃 *Metode Lain*\n🏷️ *Dana : Chat Owner*\n🏷️ *Gopay : Chat Owner*\n\n⚠️ *Dimohon Untuk Mengirim Bukti Pembayaran*\n\n❤️ *Terimakasih*',
}

global.limitawal = {
    premium: 9999999999 ,
    free: 50
}

global.multiplier = 1000

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
/* JANGAN HAPUS WM  !!
SC BY NEROX MD 
RECODE BY HAIDAR
JANGAN LUPA JOIN CH NEW GW : https://whatsapp.com/channel/0029VamzFetC6ZvcD1qde90Z
JANGAN LUPA JOIN GC GW JUGA : https://chat.whatsapp.com/JzcVI6cExQRLlPOFhI2d6u
NOMER NEW GW JANGAN LUPA SV : 6281326447234
*/