const fetch = require('node-fetch');
const fs = require('fs');
const axios = require('axios');
const cheerio = require('cheerio');

async function mediafire(url) {
    return new Promise(async (resolve, reject) => {
        try {
            const { data } = await axios.get(url);
            const $ = cheerio.load(data);

            // Mengambil informasi file
            let filename = $('.dl-info > div > div.filename').text().trim();
            let filetype = $('.dl-info > div > div.filetype').text().trim();
            let filesize = $('a#downloadButton').text().split("(")[1].split(")")[0].trim();
            let uploadAt = $('ul.details > li:nth-child(2)').text().split(": ")[1].trim();
            let link = $('#downloadButton').attr('href');
            let desc = $('div.description > p.description-subheading').text().trim();

            // Memastikan link valid
            if (typeof link === 'undefined' || link === null) {
                return resolve({ status: false, msg: 'No result found' });
            }

            let result = {
                status: true,
                filename: filename,
                filetype: filetype,
                filesize: filesize,
                uploadAt: uploadAt,
                link: link,
                desc: desc
            };

            console.log(result);
            resolve(result);
        } catch (err) {
            console.error(err);
            resolve({ status: false, msg: 'No result found' });
        }
    });
}

module.exports = {
    mediafire
};
